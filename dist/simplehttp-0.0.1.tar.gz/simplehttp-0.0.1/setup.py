from setuptools import setup, find_packages


setup(
    name = 'simplehttp',
    version='0.0.1',
    py_modules=["simplehttp"],
    package=find_packages()

)